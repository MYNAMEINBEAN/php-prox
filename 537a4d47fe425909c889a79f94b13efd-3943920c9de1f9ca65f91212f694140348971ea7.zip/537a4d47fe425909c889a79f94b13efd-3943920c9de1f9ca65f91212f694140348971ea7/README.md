## PHP Proxy Script for Iframe Embedding

### Description
This PHP script is a server-side proxy designed to bypass restrictions that prevent embedding external websites within iframes. Many websites use security headers (e.g., `X-Frame-Options` or `Content-Security-Policy`) to block their content from being displayed in iframes, leading to errors like `"Content refused to connect."` when trying to embed them directly. This proxy script retrieves the content server-side, modifies it, and delivers it to the iframe, effectively circumventing these restrictions.

### Use Case
This script is particularly useful for integrating external web pages into [Reveal.js](https://revealjs.com/) presentations. Reveal.js allows the use of iframes to display content during slideshows. However, embedding some web pages directly often fails due to security restrictions. By using this proxy script, users can include external content seamlessly in their presentations without encountering connection errors.

### Why is This Needed?
- **Bypassing Security Headers**: Websites commonly set headers like `X-Frame-Options: DENY` or `Content-Security-Policy: frame-ancestors 'none';` to prevent other sites from embedding their content. This proxy script circumvents these restrictions by fetching and serving the content server-side, enabling it to be displayed in an iframe. However, it is important to note that bypassing security headers may violate the terms of service of some websites, so use this script responsibly.
- **Handling Relative URLs**: Even when embedding is allowed, external web pages often use relative URLs that may not load correctly when proxied. The script parses and rewrites these URLs to ensure that all resources load properly.
- **Simplified Embedding**: Instead of dealing with errors and manually adjusting content, users can leverage this script to reliably embed any web page into their iframe without modifying the source.

### How It Works
1. **Server-Side Fetching**: The script takes a URL as input, validates it, and fetches the content using `cURL`.
2. **URL Rewriting**: It scans the HTML content for relative and absolute URLs (e.g., in `src`, `href`, `action` attributes, and JavaScript) and converts them to proxied URLs based on the base URL.
3. **Bypass Restrictions**: Since the content is fetched and modified server-side, restrictive headers that normally prevent embedding (e.g., `X-Frame-Options`, `Content-Security-Policy`) are removed, allowing the content to be embedded.
4. **Response Delivery**: The processed HTML is sent to the client, ensuring it renders correctly within the iframe, including any dynamically loaded resources.

### Usage
1. **Download and Deploy** the script to your server.
2. **Access the Script** via a URL:
   ```
   https://yourserver.com/iframe.php?url=https://example.com/page
   ```
3. **Embed the Proxy URL** in your Reveal.js presentation iframe:
   ```html
   <iframe src="https://yourserver.com/iframe.php?url=https://example.com/page" width="800" height="600"></iframe>
   ```

### Requirements
- **Web Server with PHP Support**: The script needs to be hosted on a web server capable of running PHP (e.g., Apache, Nginx, or similar).
- **PHP 7.0 or Higher**: The server must have PHP installed and configured. PHP 5.6 is deprecated and should not be used due to security vulnerabilities.
- **cURL Extension Enabled**: Ensure the `cURL` extension is enabled in the PHP configuration to allow server-side fetching of external content.

### Security Considerations
- **Input Validation**: Only valid URLs are processed, minimizing the risk of handling malicious input. For better security, consider implementing rate-limiting, logging, or authentication.
- **Legal and Ethical Implications**: Be aware that circumventing website security restrictions may breach the terms of service of the target website. Always ensure compliance with relevant policies and laws when using this script.

### License
This script is open-source and provided "as is." Feel free to modify and use it for your projects, but be aware of potential legal or ethical implications when bypassing website security restrictions.
